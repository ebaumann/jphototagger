package org.scribe.model;

public abstract class RequestTuner
{
  public abstract void tune(Request request);
}