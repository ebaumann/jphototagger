package com.flickr4java.flickr.photos;

public class Usage {
	
	private boolean canBlog;
	private boolean canPrint;
	private boolean canDownload;
	private boolean canShare;
	
	public boolean isCanBlog() {
		return canBlog;
	}
	public void setIsCanBlog(boolean canBlog) {
		this.canBlog = canBlog;
	}
	
	public boolean isCanPrint() {
		return canPrint;
	}
	public void setIsCanPrint(boolean canPrint) {
		this.canPrint = canPrint;
	}
	
	public boolean isCanDownload() {
		return canDownload;
	}
	public void setIsCanDownload(boolean canDownload) {
		this.canDownload = canDownload;
	}
	public boolean isCanShare() {
		return canShare;
	}
	public void setIsCanShare(boolean canShare) {
		this.canShare = canShare;
	}
	

}
