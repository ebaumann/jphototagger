package com.flickr4java.flickr.photos;

import java.util.ArrayList;

public class PoolList<E> extends ArrayList<Pool> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6749839441338939904L;
	
}
