package com.flickr4java.flickr.photos;

import java.util.ArrayList;

public class PhotoSetList<E> extends ArrayList<PhotoSet> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6749839441338939904L;
	
	

}
