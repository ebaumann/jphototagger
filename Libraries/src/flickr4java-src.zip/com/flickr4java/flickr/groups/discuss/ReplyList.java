package com.flickr4java.flickr.groups.discuss;

import java.util.ArrayList;

public class ReplyList<E> extends ArrayList<Reply> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2830506892011990291L;

}
