package com.flickr4java.flickr.cameras;

public class Details {
    private String megapixels;

    private String zoom;

    private String lcdSize;

    private String storageType;

    public String getMegapixels() {
        return megapixels;
    }

    public void setMegapixels(String megapixels) {
        this.megapixels = megapixels;
    }

    public String getZoom() {
        return zoom;
    }

    public void setZoom(String zoom) {
        this.zoom = zoom;
    }

    public String getLcdSize() {
        return lcdSize;
    }

    public void setLcdSize(String lcdSize) {
        this.lcdSize = lcdSize;
    }

    public String getStorageType() {
        return storageType;
    }

    public void setStorageType(String storageType) {
        this.storageType = storageType;
    }
}
