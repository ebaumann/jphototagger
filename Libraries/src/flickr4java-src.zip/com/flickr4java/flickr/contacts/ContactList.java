package com.flickr4java.flickr.contacts;

import com.flickr4java.flickr.SearchResultList;


public class ContactList<E> extends SearchResultList<Contact> {

    // (avoid compiler warning)
    private static final long serialVersionUID = -4735611134085303463L;

}
