package com.flickr4java.flickr.people;

import com.flickr4java.flickr.SearchResultList;

/**
 * A list of users
 * 
 * @author acaplan
 */
public class UserList<E> extends SearchResultList<User> {

    private static final long serialVersionUID = -4735611134085303463L;

}
