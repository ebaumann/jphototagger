package com.flickr4java.flickr.activity;

import com.flickr4java.flickr.SearchResultList;

public class ItemList<E> extends SearchResultList<Item> {

    private static final long serialVersionUID = 7330819045487912618L;

    public ItemList() {
    }

}
